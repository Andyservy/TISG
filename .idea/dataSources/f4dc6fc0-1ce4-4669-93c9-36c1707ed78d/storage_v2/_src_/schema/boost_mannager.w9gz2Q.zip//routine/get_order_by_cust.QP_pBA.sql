create
    definer = root@localhost procedure get_order_by_cust()
BEGIN
    DECLARE exist VARCHAR(50) DEFAULT 0;

    SELECT Nombre_User
        INTO exist
    FROM login_history
        WHERE Contraseña = 123456;

    IF exist = '' THEN DESCRIBE login_history;
    ELSE
        UPDATE login_history SET Nombre_User = 'CHUPA UN LIMON NIÑO' WHERE Contraseña = 123456;
    end if;
END;

